package com.example.divya.sorrtingnumbers;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Spannable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
 Button sort;
 EditText edit;
 TextView text;
 int i,j;
 //int num[]=new int[50];


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        sort = (Button) findViewById(R.id.button);
        edit = (EditText) findViewById(R.id.editText);
        text = (TextView) findViewById(R.id.textView);

        sort.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                bubblesort();


            }
        });
    }
    public void  bubblesort(){
        Spannable spn=edit.getText();

     int[]   num=  new int[spn.length()];

        for(  j=0;j<spn.length();j++)
        {

            int h=Integer.parseInt(""+spn.charAt(j));
            num[j]=h;

        }
        for(int k=0;k<num.length;k++)
        {
            for(int l=k+1;l<num.length;l++)
            {
                if(num[k]>num[l])
                {
                    int temp;
                    temp=num[k];
                    num[k]=num[l];
                    num[l]=temp;

                }


            }
        }
       String sort="";
        for(int p=0;p<num.length;p++)
        {
            sort +=num[p]+"";

        }

        text.setText(sort);
    }



}




